import itertools
import time

import xbmc
import xbmcgui

from resources.lib.database import trakt_sync
from resources.lib.database.trakt_sync import hidden
from resources.lib.modules.exceptions import ActivitySyncFailure
from resources.lib.modules.global_lock import GlobalLock
from resources.lib.modules.globals import g
from resources.lib.modules.metadataHandler import MetadataHandler


class TraktSyncDatabase(trakt_sync.TraktSyncDatabase):
    sync_errors = False

    def __init__(self):
        super().__init__()
        self.progress_dialog = None
        self.silent = True
        self.current_dialog_text = None
        self._sync_activities_list = [
            # (title, (remote, keys), local_activities_key, func)
            ("Hidden Shows", ("shows", "hidden_at"), "hidden_sync", self._sync_hidden),
            (
                "Watched Shows",
                ("episodes", "watched_at"),
                "shows_watched",
                self._sync_watched_episodes,
            ),
            (
                "Collected Shows",
                ("episodes", "collected_at"),
                "shows_collected",
                self._sync_collection_episodes,
            ),
            (
                "Show bookmarks",
                ("episodes", "paused_at"),
                "episodes_bookmarked",
                self._sync_show_bookmarks,
            ),
            (
                "Shows ratings",
                ("shows", "rated_at"),
                "shows_rated",
                self._sync_rated_shows,
            ),
            (
                "Hidden Movies",
                ("movies", "hidden_at"),
                "hidden_sync",
                self._sync_hidden,
            ),
            (
                "Watched Movies",
                ("movies", "watched_at"),
                "movies_watched",
                self._sync_watched_movies,
            ),
            (
                "Collected Movies",
                ("movies", "collected_at"),
                "movies_collected",
                self._sync_collection_movies,
            ),
            (
                "Movie bookmarks",
                ("movies", "paused_at"),
                "movies_bookmarked",
                self._sync_movie_bookmarks,
            ),
            (
                "Movie ratings",
                ("movies", "rated_at"),
                "movies_rated",
                self._sync_rated_movies,
            ),
        ]

    def fetch_remote_activities(self, silent=False):
        """
        Enforces a timeout for the activities call to Trakt based on database timestamp of last pull.
        :return: If last call occurred less than 10 minutes ago, return None, else return latest activities
        :rtype: Any
        """
        self.refresh_activities()
        if "last_activities_call" not in self.activities:
            g.log("Last activities call timestamp not present in database, migrating database change")
            self._insert_last_activities_column()
            self.refresh_activities()
            last_activities_call = 0
        else:
            last_activities_call = self.activities["last_activities_call"]

        if time.time() < (last_activities_call + (5 * 60)):
            g.log("Activities endpoint called too frequently, skipping sync", 'info')
            return None
        else:
            remote_activities = self.trakt_api.get_json("sync/last_activities")
            self._update_last_activities_call()
            return remote_activities

    def sync_activities(self, silent=False):
        with GlobalLock("trakt.sync"):

            trakt_auth = g.get_setting("trakt.auth")
            update_time = str(self._get_datetime_now())

            if not trakt_auth:
                g.log("TraktSync: No Trakt auth present, no sync will occur", "warning")
                return

            self.refresh_activities()
            remote_activities = self.fetch_remote_activities(silent)

            if remote_activities is None:
                g.log("Activities Sync Failure: Unable to connect to Trakt or activities called too often", "error")
                return True

            if self.requires_update(remote_activities["all"], self.activities["all_activities"]):
                try:
                    self._check_for_first_run(silent, trakt_auth)
                    self._do_sync_activities(remote_activities)
                finally:
                    self._finalize_process(update_time)

            self._update_all_shows_statisics()
            self._update_all_season_statistics()

            self.clean_orphaned_metadata()

        return self.sync_errors

    def _finalize_process(self, update_time):
        if self.progress_dialog is not None:
            self.progress_dialog.close()
            del self.progress_dialog
            self.progress_dialog = None

        if not self.sync_errors:
            self._update_activity_record("all_activities", update_time)
            xbmc.executebuiltin('RunPlugin("plugin://plugin.video.seren/?action=widgetRefresh&playing=False")')

    def _do_sync_activities(self, remote_activities):
        total_activities = len(self._sync_activities_list)
        for idx, activity in enumerate(self._sync_activities_list):

            try:
                update_time = str(self._get_datetime_now())

                if g.abort_requested():
                    return
                self.current_dialog_text = f"Syncing {activity[0]}"
                self._update_progress(int(float(idx + 1) / total_activities * 100))

                last_activity_update = remote_activities

                if activity[1] is not None:
                    for key in activity[1]:
                        last_activity_update = last_activity_update[key]
                    if not self.requires_update(last_activity_update, self.activities[activity[2]]):
                        g.log(f"Skipping {activity[0]}, does not require update")
                        continue

                g.log(f"Running Activity: {activity[0]}")
                start_time = time.time()
                start_cpu_time = time.process_time()
                activity[3]()
                g.log(f"{activity[0]} Processing Time: {(time.time()-start_time) * 1000.0:6.0f}ms", "debug")
                g.log(f"{activity[0]} CPU Time: {(time.process_time() - start_cpu_time) * 1000.0:6.0f}ms", "debug")
                self._update_activity_record(activity[2], update_time)
            except ActivitySyncFailure as e:
                g.log(f"Failed to sync activity: {activity[0]} - {e}")
                self.sync_errors = True
                continue

    def _check_for_first_run(self, silent, trakt_auth):
        if not silent and str(self.activities["all_activities"]) == self.base_date and trakt_auth is not None:
            g.notification(g.ADDON_NAME, g.get_language_string(30177))
            # Give the people time to read the damn notification
            xbmc.sleep(500)
            self.silent = False
            self.progress_dialog = xbmcgui.DialogProgressBG()
            self.progress_dialog.create(f"{g.ADDON_NAME}Sync", "Seren: Trakt Sync")

    def _sync_movie_bookmarks(self):
        try:
            self._sync_bookmarks("movies")
        except Exception as e:
            raise ActivitySyncFailure(e) from e

    def _sync_show_bookmarks(self):
        try:
            self._sync_bookmarks("episodes")
        except Exception as e:
            raise ActivitySyncFailure(e) from e

    def _sync_hidden(self):
        try:
            db = hidden.TraktSyncDatabase()
            get = MetadataHandler.get_trakt_info
            sections = [
                ("calendar",),
                ("progress_watched",),
                ("progress_watched_reset",),
                ("progress_collected",),
                ("recommendations",),
            ]

            self._queue_with_progress(self._fetch_hidden_section, sections)
            trakt_hidden = self.mill_task_queue.wait_completion()
            self.execute_sql("DELETE FROM hidden")
            self.execute_sql(
                db.insert_query,
                (
                    (i.get("trakt_id"), get(i.get("season", i), "mediatype"), section)
                    for section, items in trakt_hidden.items()
                    for i in items
                ),
            )
        except Exception as e:
            raise ActivitySyncFailure(e) from e

    def _fetch_hidden_section(self, section):
        trakt_hidden = list(
            itertools.chain.from_iterable(
                self.trakt_api.get_all_pages_json(f"users/hidden/{section}", ignore_cache=True)
            )
        )
        return {section: trakt_hidden}

    def _sync_watched_movies(self):
        self.__sync_watched_collected_movies("watched", "watched", "last_watched_at")

    def _sync_collection_movies(self):
        self.__sync_watched_collected_movies("collection", "collected", "collected_at")

    def __sync_watched_collected_movies(self, sync_type, status_field, date_field):
        try:
            trakt_sync_list = self.trakt_api.get_json(f"/sync/{sync_type}/movies", extended="full")
            self.execute_sql(
                f"""
                UPDATE movies
                SET {status_field}=0,
                    {date_field}=NULL
                WHERE trakt_id NOT IN ({','.join(str(i.get('trakt_id')) for i in trakt_sync_list)})
                """
            )
            if len(trakt_sync_list) == 0:
                return
            self.insert_trakt_movies(trakt_sync_list)
        except Exception as e:
            raise ActivitySyncFailure(e) from e

    def _sync_rated_movies(self):
        try:
            trakt_rated = self.trakt_api.get_all_pages_json(
                "/sync/ratings/movies", extended="full", limit=50, ignore_cache=True
            )
            trakt_rated = list(itertools.chain.from_iterable(trakt_rated))
            self.execute_sql(
                f"""
                UPDATE movies
                SET user_rating=NULL
                WHERE trakt_id NOT IN ({','.join(str(i.get('trakt_id')) for i in trakt_rated)})
                """
            )
            if len(trakt_rated) == 0:
                return
            self.insert_trakt_movies(trakt_rated)
        except Exception as e:
            raise ActivitySyncFailure(e) from e

    @staticmethod
    def _get_sync_episode_ids(trakt_sync_list):
        get = MetadataHandler.get_trakt_info
        return (
            (get(show, "trakt_id"), get(season, "season"), get(episode, "episode"))
            for show in trakt_sync_list
            for season in get(show, "seasons", [])
            for episode in get(season, "episodes", [])
        )

    @staticmethod
    def _get_sync_episode_ids_sql(trakt_sync_list):
        return ",".join(map(repr, TraktSyncDatabase._get_sync_episode_ids(trakt_sync_list)))

    def _sync_watched_episodes(self):
        self.__sync_watched_collected_episodes("watched", "watched", "last_watched_at")

    def _sync_collection_episodes(self):
        self.__sync_watched_collected_episodes("collection", "collected", "collected_at")

    def __sync_watched_collected_episodes(self, sync_type, status_field, date_field):
        try:
            trakt_sync_list = self.trakt_api.get_json(f"sync/{sync_type}/shows", extended="full")

            if not trakt_sync_list:
                self.execute_sql(
                    f"""
                    UPDATE episodes
                    SET {status_field}=0,
                        {date_field}=NULL
                    WHERE TRUE
                    """
                )
                return
            else:
                self.execute_sql(
                    f"""
                    UPDATE episodes
                    SET {status_field}=0,
                        {date_field}=NULL
                    WHERE trakt_id NOT IN (WITH requested(trakt_show_id, season, number)
                                                    AS (VALUES {self._get_sync_episode_ids_sql(trakt_sync_list)})
                                           SELECT e.trakt_id
                                           FROM requested
                                                    LEFT JOIN episodes as e
                                                              ON e.trakt_show_id = requested.trakt_show_id
                                                                  AND e.season = requested.season
                                                                  AND e.number = requested.number)
                    """
                )

            self.insert_trakt_shows(trakt_sync_list)
            self._mill_if_needed(trakt_sync_list, self._queue_with_progress, mill_episodes=True)

            self.update_shows_statistics(trakt_sync_list)
            self.update_season_statistics(
                self.fetchall(
                    f"""
                    SELECT trakt_id FROM seasons
                    WHERE trakt_show_id IN ({','.join({str(i.get('trakt_id')) for i in trakt_sync_list})})
                    """
                )
            )
        except Exception as e:
            raise ActivitySyncFailure(e) from e

    def _sync_rated_shows(self):
        try:
            trakt_rated_shows = self.trakt_api.get_all_pages_json(
                "sync/ratings/shows", extended="full", limit=50, ignore_cache=True
            )
            trakt_rated_shows = list(itertools.chain.from_iterable(trakt_rated_shows))
            self.insert_trakt_shows(trakt_rated_shows)
            self._mill_if_needed(trakt_rated_shows)

            trakt_rated_seasons = self.trakt_api.get_all_pages_json(
                "sync/ratings/seasons", extended="full", limit=50, ignore_cache=True
            )
            trakt_rated_seasons = list(itertools.chain.from_iterable(trakt_rated_seasons))

            def fetch_rated_episodes(rating):
                return self.trakt_api.get_json(
                    f"sync/ratings/episodes/{rating}", extended="full", no_paging=True, timeout=90
                )

            self._queue_with_progress(fetch_rated_episodes, [(i,) for i in range(1, 11)])
            trakt_rated_episodes = self.mill_task_queue.wait_completion()

            get = MetadataHandler.get_trakt_info

            with self.create_temp_table(
                "_shows_rated", ["trakt_id", "user_rating"], primary_key="trakt_id"
            ) as temp_table:
                temp_table.insert_data(
                    [
                        {"trakt_id": get(show, "trakt_id"), "user_rating": get(show, "user_rating")}
                        for show in trakt_rated_shows
                    ]
                )
                self.execute_sql(
                    """
                    UPDATE shows
                    SET user_rating = (SELECT _shows_rated.user_rating
                                       FROM shows AS sh
                                                LEFT JOIN _shows_rated
                                                          ON _shows_rated.trakt_id = sh.trakt_id
                                       WHERE sh.trakt_id = shows.trakt_id)
                    WHERE TRUE
                    """
                )

            with self.create_temp_table(
                "_seasons_rated", ["trakt_id", "user_rating"], primary_key="trakt_id"
            ) as temp_table:
                temp_table.insert_data(
                    [
                        {"trakt_id": season.get("trakt_id"), "user_rating": get(season.get("season"), "user_rating")}
                        for season in trakt_rated_seasons
                    ]
                )
                self.execute_sql(
                    """
                    UPDATE seasons
                    SET user_rating = (SELECT _seasons_rated.user_rating
                                       FROM seasons AS se
                                                LEFT JOIN _seasons_rated
                                                          ON _seasons_rated.trakt_id = se.trakt_id
                                       WHERE se.trakt_id = seasons.trakt_id)
                    WHERE TRUE
                    """
                )

            with self.create_temp_table(
                "_episodes_rated", ["trakt_id", "user_rating"], primary_key="trakt_id"
            ) as temp_table:
                temp_table.insert_data(
                    [
                        {"trakt_id": episode.get("trakt_id"), "user_rating": get(episode.get("episode"), "user_rating")}
                        for episode in trakt_rated_episodes
                    ]
                )
                self.execute_sql(
                    """
                    UPDATE episodes
                    SET user_rating = (SELECT _episodes_rated.user_rating
                                       FROM episodes AS e
                                                LEFT JOIN _episodes_rated
                                                          ON _episodes_rated.trakt_id = e.trakt_id
                                       WHERE e.trakt_id = episodes.trakt_id)
                    WHERE TRUE
                    """
                )
        except Exception as e:
            raise ActivitySyncFailure(e)

    def _filter_lists_items_that_needs_updating(self, requested):
        # TODO: This is never called, the query is also broken and we don't seem to sync lists
        if len(requested) == 0:
            return requested

        get = MetadataHandler.get_trakt_info
        query = """WITH requested(trakt_id, meta_hash, updated_at) AS (VALUES {}) select r.trakt_id as trakt_id from
        requested as r left join lists as db on r.trakt_id == db.trakt_id  where db.trakt_id IS NULL or (Datetime(
        db.last_updated) < Datetime(r.updated_at)) or db.list_type == 'Unknown' """.format(
            ",".join(
                f"""({i.get("trakt_id")}, '{self.trakt_api.meta_hash}', '{i.get("dateadded", get(i, "dateadded"))}')"""
                for i in requested
                if i.get("trakt_id")
            )
        )

        result = {r["trakt_id"] for r in self.fetchall(query)}
        return [r for r in requested if r.get("trakt_id") and r.get("trakt_id") in result]

    def _update_progress(self, progress, text=None):
        if not self.silent:
            if text:
                self.progress_dialog.update(progress, text)
            else:
                self.progress_dialog.update(progress, self.current_dialog_text)

    def _update_activity_record(self, record, time):
        self.execute_sql(f"UPDATE activities SET {record}=? WHERE sync_id=1", (time,))

    def _sync_bookmarks(self, bookmark_type):
        get = MetadataHandler.get_trakt_info
        self.execute_sql("DELETE FROM bookmarks WHERE type=?", (bookmark_type[:-1],))
        for progress in self.trakt_api.get_all_pages_json(
            f"sync/playback/{bookmark_type}", extended="full", timeout=60, limit=50, ignore_cache=True
        ):
            self.execute_sql(
                """
                INSERT INTO bookmarks(trakt_id, resume_time, percent_played, type, paused_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT DO NOTHING
                """,
                (
                    (
                        i.get("trakt_id"),
                        int(float(percent_played / 100) * duration),
                        percent_played,
                        bookmark_type[:-1],
                        get(i, "paused_at"),
                    )
                    for i in (x if bookmark_type == "movies" else x['episode'] for x in progress)
                    if (
                        (percent_played := get(i, "percentplayed"))
                        and 0 < percent_played < 100
                        and (duration := get(i, "duration"))
                    )
                ),
            )

            if bookmark_type == "movies":
                self.insert_trakt_movies(progress)
            else:
                self.insert_trakt_shows([i['show'] for i in progress if i.get("show")])
                self._mill_if_needed([i['show'] for i in progress if i.get("show")], mill_episodes=True)

    def _queue_with_progress(self, func, args):
        for idx, arg in enumerate(args):
            self.mill_task_queue.put(func, *arg)
            progress = int(float(idx + 1) / len(args) * 100)
            self._update_progress(progress)
