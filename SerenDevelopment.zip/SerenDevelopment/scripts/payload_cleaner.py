import argparse
import os
import time

from vcr.serializers import jsonserializer
from vcr.serializers import yamlserializer


class PayloadCleaner:
    serializer = {"yaml": yamlserializer, "json": jsonserializer}

    def __init__(self, cassette_path, cassette_suffix, cassette_serializer):
        self.cassette_serializer = self.serializer[cassette_serializer]
        self.cassette_suffix = cassette_suffix
        self.cassette_path = cassette_path
        self.payloads = {}
        self.index = set()
        self._index_cassettes()

    def _index_cassettes(self):
        for root, dirs, files in os.walk(self.cassette_path):
            for f in files:
                if f.endswith(self.cassette_suffix):
                    if ".payloads" in root:
                        self.payloads.update({self._trim_right(f, self.cassette_suffix): os.path.join(root, f)})
                    else:
                        index = self._load_cassette(os.path.join(root, f), self.cassette_serializer)
                        for r in index.get("records", []):
                            self.index.add(r)

    def clean_orphaned_payloads(self):
        for k, v in self.payloads.items():
            if k not in self.index:
                os.remove(v)

    @staticmethod
    def _trim_right(s, suffix):
        return s[: -len(suffix)] if suffix and s.endswith(suffix) else s

    @staticmethod
    def _load_from_disk(path):
        with open(path, encoding="utf-8") as f:
            return f.read()

    def _load_cassette(self, cassette_path, serializer):
        cassette_content = self._load_from_disk(cassette_path)
        return serializer.deserialize(cassette_content)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("filenames", metavar="filename", type=str, nargs="*", help="filenames to be processed")
    parser.add_argument("--path", default=".", help="Path to the cassette folder")
    parser.add_argument("--cassette-suffix", default=".yaml", help="Suffix from the cassettes")
    parser.add_argument("--cassette-serializer", default="yaml", help="Serializer used to serialize the cassettes")
    args = parser.parse_args()

    if args.filenames and all(".payload" not in f for f in args.filenames):
        print("Nothing to do!")
        return

    start_time = time.time()
    cleaner = PayloadCleaner(os.path.abspath(args.path), args.cassette_suffix, args.cassette_serializer)
    cleaner.clean_orphaned_payloads()

    print(f"Done! ({time.time() - start_time})")


if __name__ == "__main__":
    main()
