import os
import xml.etree.ElementTree as ElementTree
import zipfile

from resources.lib.common import tools


class ArtifactGenerator:
    def __init__(self):
        self.base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        self.artifact_path = os.path.join(self.base_path, "artifact")
        tools.makedirs(self.artifact_path, exist_ok=True)

    def create_zip(self):
        xml = ElementTree.parse(os.path.join(self.base_path, "addon.xml"))
        addon = xml.find(".")
        addon_id = addon.attrib["id"]
        version = addon.attrib["version"]
        git_sha = self.read_all_text(os.path.join(self.base_path, ".gitsha")) or "local"

        final_zip = os.path.join(self.artifact_path, f"{addon_id}-{version}-{git_sha}.zip")

        print(f"Creating zip for: {addon_id} v.{version} - {git_sha}")
        zip_file = zipfile.ZipFile(final_zip, "w", compression=zipfile.ZIP_DEFLATED)
        root_len = len(os.path.dirname(self.base_path))

        ignore = [
            ".git",
            ".github",
            ".gitignore",
            ".DS_Store",
            "thumbs.db",
            ".idea",
            "venv",
            ".pylintrc",
            ".gitlab-ci.yml",
            ".idea",
            "venv",
            ".pytest_cache",
            "mock_kodi",
            "tests",
            "scripts",
            "__pycache__",
            ".pyo",
            ".pyc",
            "test.py",
            "artifact",
        ]

        for root, dirs, files in os.walk(self.base_path):
            # remove any unneeded git artifacts
            for i in ignore:
                if i in dirs:
                    try:
                        dirs.remove(i)
                    except Exception:
                        pass
                for f in files:
                    if f.startswith(i) or f.endswith(i):
                        try:
                            files.remove(f)
                        except Exception:
                            pass

            archive_root = os.path.abspath(root)[root_len:]

            for f in files:
                full_path = os.path.join(root, f)
                archive_name = os.path.join(archive_root, f)
                zip_file.write(full_path, archive_name, zipfile.ZIP_DEFLATED)

        zip_file.close()

    @staticmethod
    def read_all_text(file_path):
        try:
            with open(file_path) as f:
                return f.read()
        except OSError:
            return None


if __name__ == "__main__":
    artifact_generator = ArtifactGenerator()
    artifact_generator.create_zip()
