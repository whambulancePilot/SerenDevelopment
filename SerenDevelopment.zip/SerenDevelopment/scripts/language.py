import argparse
import os
import re
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

import polib
import requests

HTML_CODES = (
    ("'", "&#39;"),
    ('"', "&quot;"),
    (">", "&gt;"),
    ("<", "&lt;"),
    ("&", "&amp;"),
    ("\n", "&#10;"),
    ("`", "&apos;"),
)


class CachedFileWriter:
    def __init__(self):
        self.file_cache = {}
        self.files_to_write = set()

    def read_file(self, path, file):
        file_path = os.path.join(path, file.lstrip(os.sep))
        if file_path not in self.file_cache:
            with open(file_path, encoding="utf8") as file:
                self.file_cache[file_path] = file.read()

        return self.file_cache[file_path]

    def save_file(self, path, file, content):
        file_path = os.path.join(path, file.lstrip(os.sep))
        if file_path in self.file_cache and self.file_cache[file_path] != content:
            self.files_to_write.add(file_path)
        self.file_cache[file_path] = content

    def write_to_disk(self):
        for f in self.files_to_write:
            with open(f, "w", encoding="utf8") as new_file:
                new_file.write(self.file_cache[f])


class LanguageAnalyzer:
    def __init__(self, project_path, key=None):
        self.key = key
        self.all_codes = set()
        self.project_codes = set()
        self.language_codes = {}
        self.language_files = {}
        self.files_index = {}
        self.language_code_regex = re.compile(
            r"(?<![0-9a-z])([34][0-9]{4})(?![0-9a-z])(?!(?:\s*?,\s*?(?:addon\s*?=\s*?)?False)|(?:.*?#.*?no-translate))",
            re.IGNORECASE,
        )
        self.only_digits = re.compile(r"\D")
        self.replace_regex_format = "(?<![0-9a-zA-Z])({})(?![0-9a-zA-Z])"
        self.session = requests.Session()
        self.project_path = project_path
        self.compiled_pattern_cache = {}
        self.files = CachedFileWriter()

    def _index_languages(self):
        for root, dirs, files in os.walk(os.path.join(self.project_path, "resources", "language")):
            for f in files:
                if f.endswith(".po"):
                    self._index_language(os.path.join(root, f))

    def _index_language(self, file):
        lang = os.path.dirname(file).split(".")[-1]
        po = polib.pofile(file)
        codes = {int(self.only_digits.sub("", entry.msgctxt)) for entry in po}
        self.all_codes.update(codes)
        self.language_files[lang] = {"file": file, "po": po}
        self.language_codes[lang] = codes

    def _index_project(self):
        self.files_index = {}
        self.project_codes = set()
        self._walk_project(self._index_file)

    def _walk_project(self, func, **params):
        for root, dirs, files in os.walk(self.project_path):
            dirs[:] = [
                d
                for d in dirs
                if d not in [".idea", ".git", ".venv", "venv", "tests", "mock_kodi", "scripts", "hooks", "third_party"]
            ]
            for f in files:
                if not f.endswith((".py", ".xml")):
                    continue
                func(f=f, content=self.files.read_file(root, f), root=root, **params)

    def _index_file(self, **params):
        root = params.pop("root")
        content = params.pop("content")
        f = params.pop("f")
        relative_path = os.path.join(root.replace(self.project_path, ""), f)
        for idx, line in enumerate(content.splitlines()):
            for number in self.language_code_regex.findall(line):
                numeric = int(number)
                if numeric not in self.files_index:
                    self.files_index[numeric] = []
                self.files_index[numeric].append((relative_path, idx))
                self.project_codes.add(numeric)

    def _replace_occurrences(self, **params):
        root = params.pop("root")
        old_content = params.pop("content")
        f = params.pop("f")
        code_from = int(params.pop("code_from"))
        code_to = int(params.pop("code_to"))
        if code_from not in self.compiled_pattern_cache:
            self.compiled_pattern_cache[code_from] = re.compile(self.replace_regex_format.format(code_from))

        self.files.save_file(root, f, self.compiled_pattern_cache[code_from].sub(str(code_to), old_content))

    def analyze_project(self):
        self._index_languages()
        self._index_project()

        for lang, codes in self.language_codes.items():
            print(f"Analyzing language: {lang}")
            print(f"Missing these code: {self.project_codes - codes}")
            print(f"Not used code: {codes - self.project_codes}")
            print(f"Percent translated: {self.language_files[lang]['po'].percent_translated()}")

        print(f"Duplicate entries found: {self._get_duplicates().keys()}")
        print(f"Global not used in code: {self.all_codes - self.project_codes}")
        print(f"Global available for use: {set(range(30000, max(self.all_codes) + 1)) - self.all_codes}")

    def _get_duplicates(self):
        duplicates = {}
        for entry in self.language_files['en_gb']['po']:
            if entry.msgid in duplicates:
                duplicates[entry.msgid]['count'] += 1
                duplicates[entry.msgid]['duplicates'].append(int(self.only_digits.sub("", entry.msgctxt)))
            else:
                duplicates[entry.msgid] = {
                    "count": 1,
                    "first": int(self.only_digits.sub("", entry.msgctxt)),
                    "duplicates": [],
                }
        return {key: value for key, value in duplicates.items() if value["count"] > 1}

    def _remove_duplicates(self):
        duplicates = self._get_duplicates()
        duplicate_codes = {d for x in duplicates.values() for d in x['duplicates']}
        for lang, file in self.language_files.items():
            self._remove_not_used_entries(file["po"], duplicate_codes)

        for d in duplicates.values():
            for x in d['duplicates']:
                self._walk_project(self._replace_occurrences, code_from=x, code_to=d['first'])

    def auto_translate_missing_entries(self):
        print("Translating new entries:")
        self._index_languages()
        try:
            with ThreadPoolExecutor(max_workers=20) as executor:
                for lang, po in self.language_files.items():
                    if lang == "en_gb":
                        continue

                    for result in executor.map(
                        lambda args: self._try_translate_entry(*args),
                        (
                            (entry, index, lang, po["po"][index])
                            for index, entry in enumerate(self.language_files['en_gb']['po'])
                        ),
                    ):
                        po['po'][result[0]] = result[1]
        except Exception:
            traceback.print_exc()
        self._save_files()

    def _try_translate_entry(self, entry, index, lang, dest_po):
        entry.msgstr = entry.msgid
        if entry.msgid.lower() != dest_po.msgid.lower():
            dest_po.msgid = entry.msgid
            dest_po.msgstr = None
        if not dest_po.msgstr:
            print(f"\t{lang}: {entry.msgctxt.lstrip('#')}")
            dest_po.msgstr = self._try_get_translation(dest_po.msgid, lang.split("_")[0])
        return index, dest_po

    def clean_project(self):
        self._index_languages()
        self._index_project()

        for lang, codes in self.language_codes.items():
            print(f"Cleanup language: {lang}")
            print(f"Adding missing codes: {self.project_codes - codes}")
            self._add_missing_entries(self.language_files[lang]["po"], self.project_codes - codes)
            print(f"Removing Not used code: {codes - self.project_codes}")
            self._remove_not_used_entries(self.language_files[lang]["po"], codes - self.project_codes)

        print("Removing duplicates")
        self._remove_duplicates()
        self.files.write_to_disk()
        self._save_files()

    def fill_gaps(self):
        self._index_languages()
        self._index_project()
        print("Filling gaps in project codes")
        sorted_codes = sorted(self.project_codes, reverse=True)

        for code_to in sorted(set(range(30000, 30000 + len(self.project_codes))) - self.project_codes):
            code_from = sorted_codes.pop(0)
            self._change_po_lang_code(code_from, code_to)
            for f, index in self.files_index[code_from]:
                self._replace_occurrences(
                    root=self.project_path,
                    f=f,
                    content=self.files.read_file(self.project_path, f),
                    code_from=code_from,
                    code_to=code_to,
                )
        self.files.write_to_disk()
        self._save_files()

    def _save_files(self):
        self._update_occurrences()
        [i["po"].save(i["file"]) for i in self.language_files.values()]

    @staticmethod
    def _missing_numbers(num_list):
        original_list = list(range(num_list[0], num_list[-1] + 1))
        num_list = set(num_list)
        return list(num_list ^ set(original_list))

    def _update_occurrences(self):
        self._index_project()
        for lang, codes in self.language_codes.items():
            for entry in self.language_files[lang]["po"]:
                if occurrences := self.files_index.get(int(self.only_digits.sub("", entry.msgctxt))):
                    entry.occurrences = [(f.replace("\\", "/"), index) for f, index in occurrences]
                else:
                    entry.occurrences = None

    def _add_missing_entries(self, po, codes):
        for entry in self.language_files['en_gb']["po"]:
            if any(str(c) in entry.msgctxt for c in codes):
                entry.msgstr = ""
                po.append(entry)

    @staticmethod
    def _remove_not_used_entries(po, codes):
        to_remove = [entry for entry in po if any(str(c) in entry.msgctxt for c in codes)]
        [po.remove(entry) for entry in to_remove]

    def _change_po_lang_code(self, code_from, code_to):
        for lang, codes in self.language_codes.items():
            for entry in self.language_files[lang]["po"]:
                if str(code_from) in str(entry.msgctxt):
                    entry.msgctxt = entry.msgctxt.replace(str(code_from), str(code_to))

    def _try_get_translation(self, value, lang):
        data = self.session.get(
            "https://api.mymemory.translated.net/get",
            params={"q": value, "langpair": f"en|{lang}", "key": self.key},
        ).json()
        if not data:
            raise Exception("")
        if not data['responseData']['translatedText']:
            Exception(data['responseData'])
        if "MYMEMORY" in data['responseData']['translatedText']:
            raise Exception(data['responseData']['translatedText'])

        matches = data['matches']
        return next(
            (
                value.replace(match['segment'], self._html_decode(match['translation']))
                for match in sorted(matches, key=lambda x: x['match'], reverse=True)
                if match['segment'] in value
            ),
            value,
        )

    @staticmethod
    def _html_decode(s):
        for code in HTML_CODES:
            s = s.replace(code[1], code[0])
        return s


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("filenames", metavar="filename", type=str, nargs="*", help="filenames to be processed")
    parser.add_argument("--key", help="key to be used to request the translations")
    parser.add_argument("--path", default=".", help="root path of the project")
    args = parser.parse_args()

    start_time = time.time()

    if args.filenames and not any(f.endswith(".po") for f in args.filenames):
        print("Nothing to do!")
        return

    analyzer = LanguageAnalyzer(os.path.abspath(args.path), args.key)
    analyzer.analyze_project()
    analyzer.clean_project()
    analyzer.fill_gaps()
    analyzer.auto_translate_missing_entries()
    print(f"Done! ({time.time() - start_time})")


if __name__ == "__main__":
    main()
