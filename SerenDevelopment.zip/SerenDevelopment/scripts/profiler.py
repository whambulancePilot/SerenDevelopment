import cProfile
import pstats
from functools import wraps
from io import StringIO


def profile(outerfunc=None, *, sort="time", limit=0.1, min_exec_time=None, strip_dirs=True, callers=False):
    """
    Decorator that performs profiling of the function and prints results out
    Does some stream formatting to make sure it comes back as a single log output for Kodi logging

    :param sort: pstats.Stats sort type. Default: "time"
    :type sort: str
    :param limit: Limit the results. Default: 0.1 (10%)
    :type limit: float
    :param min_exec_time: Minimum time for execution in seconds before the profiler will return detailed statistics
    :type min_exec_time: float
    :param strip_dirs: Whether to strip the directory paths from functions.  Default: True
    :type limit: bool
    :param callers: Whether to obtain the callers to the sorted, limited profile statistcs.  Default: False
    :type callers: bool
    :return: The wrapped function
    :rtype: function
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            profiler = cProfile.Profile()
            result = profiler.runcall(func, *args, **kwargs)
            stats_output = StringIO()
            stats_output.write(f"PROFILER RESULTS FOR: {func.__qualname__}\n\n")
            stats = pstats.Stats(profiler, stream=stats_output)
            if min_exec_time and stats.total_tt < min_exec_time:
                stats_output.write(f"{stats.total_calls} function calls in {stats.total_tt:.4} seconds")
            else:
                if strip_dirs:
                    stats.strip_dirs()
                stats.sort_stats(sort)
                stats.print_stats(limit)
                if callers:
                    stats.print_callers(limit)
            print(stats_output.getvalue())
            return result

        return wrapper

    return decorator(outerfunc) if outerfunc else decorator
